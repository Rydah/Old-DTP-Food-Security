from org.transcrypt.stubs.browser import *

# write down any library you need for the client
# this uses Transcrypt to create the javascript library

