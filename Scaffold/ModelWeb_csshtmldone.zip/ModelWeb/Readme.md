This template is based on mp_calc project. Modify it to suit your needs.
